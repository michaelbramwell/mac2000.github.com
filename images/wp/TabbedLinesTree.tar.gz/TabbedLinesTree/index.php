<?php
require_once 'TabbedLinesTree.php';

$text = "Line 1
Line 2
	Line 2.1
	Line 2.2
        
Line 3";

$dom = TabbedLinesTree::parse($text);

echo $dom->saveXML();
/* Will output:

<?xml version="1.0" encoding="utf-8"?>
<items>
  <item value="Line 1"/>
  <item value="Line 2">
    <item value="Line 2.1"/>
    <item value="Line 2.2"/>
  </item>
  <item value="Line 3"/>
</items>
 */