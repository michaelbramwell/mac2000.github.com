(function($) {

Drupal.wysiwyg.codemirror = {}; // CodeMirror instances storage

/**
 * Attach this editor to a target element.
 *
 * See Drupal.wysiwyg.editor.attach.none() for a full desciption of this hook.
 */
Drupal.wysiwyg.editor.attach.codemirror = function(context, params, settings) {
	if(typeof params != 'undefined') {
		Drupal.wysiwyg.codemirror[params.field] = CodeMirror.fromTextArea(document.getElementById(params.field), {
			lineNumbers: Drupal.settings.wysiwyg.configs.codemirror.format5.lineNumbers,//true,
			matchBrackets: true,
			mode: "application/x-httpd-php",
			indentUnit: 4,
			indentWithTabs: Drupal.settings.wysiwyg.configs.codemirror.format5.indentWithTabs,//true,
			enterMode: "keep",
			tabMode: "shift"
		});
	}
};

/**
 * Detach a single or all editors.
 *
 * See Drupal.wysiwyg.editor.detach.none() for a full desciption of this hook.
 */
Drupal.wysiwyg.editor.detach.codemirror = function(context, params) {
	if(typeof params != 'undefined') {
		Drupal.wysiwyg.codemirror[params.field].toTextArea();
		delete Drupal.wysiwyg.codemirror[params.field];
	}
};

})(jQuery);
