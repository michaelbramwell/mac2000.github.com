<?php
//zf create db-table Customer customer
class Application_Model_DbTable_Customer extends Zend_Db_Table_Abstract
{

    protected $_name = 'customer';

}

