<?php

//zf create controller Customer
class CustomerController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $this->_redirect('/customer/list');
    }

    //zf create action list Customer
    public function listAction()
    {
        $customerMapper = new Application_Model_CustomerMapper();
        $this->view->entries = $customerMapper->fetchAll();
    }

    //zf create action view Customer
    public function viewAction()
    {
        $id = (int) $this->getRequest()->getParam('id');
        $customerMapper = new Application_Model_CustomerMapper();
        $this->view->entry = $customerMapper->find($id);
    }

    //zf create action create Customer
    public function createAction()
    {
        $form = new Application_Form_CustomerForm();
        $form->setAction('/customer/create');
        $form->setMethod('post');

        if ($this->getRequest()->isPost()) {
            if ($form->isValid($_POST)) {

                $customerMapper = new Application_Model_CustomerMapper();

                $customer = new Application_Model_Customer();
                $customer->setActive($form->getValue('active'))
                        ->setAge($form->getValue('age'))
                        ->setEmail($form->getValue('email'))
                        ->setFirstName($form->getValue('firstName'))
                        ->setLastName($form->getValue('lastName'));

                $customerMapper->save($customer);

                if ($customer->getId()) {
                    $this->_forward('list');
                }
            }
        }

        $this->view->form = $form;
    }

    //zf create action edit Customer
    public function editAction()
    {
        $form = new Application_Form_CustomerForm();
        $form->setAction('/customer/edit');
        $form->setMethod('post');

        $customerMapper = new Application_Model_CustomerMapper();

        if ($this->getRequest()->isPost()) {
            if ($form->isValid($_POST)) {
                $customer = new Application_Model_Customer();

                $customer->setId($form->getValue('id'))
                        ->setActive($form->getValue('active'))
                        ->setAge($form->getValue('age'))
                        ->setEmail($form->getValue('email'))
                        ->setFirstName($form->getValue('firstName'))
                        ->setLastName($form->getValue('lastName'));

                $customerMapper->save($customer);

                $this->_forward('list');
            }
        } else {
            $id = $this->getRequest()->getParam('id');
            $customer = $customerMapper->find($id);

            $values = array(
                'id' => $customer->getId(),
                'firstName' => $customer->getFirstName(),
                'lastName' => $customer->getLastName(),
                'email' => $customer->getEmail(),
                'age' => $customer->getAge(),
                'active' => $customer->getActive(),
            );

            $form->populate($values);
        }

        $this->view->form = $form;
    }

    //zf create action delete Customer
    public function deleteAction()
    {
        $id = $this->getRequest()->getParam('id');
        $customerMapper = new Application_Model_CustomerMapper();
        $customerMapper->delete($id);
        $this->_redirect('/customer/list');
    }

}


