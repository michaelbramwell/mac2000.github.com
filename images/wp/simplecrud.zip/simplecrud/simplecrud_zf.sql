-- MySQL dump 10.13  Distrib 5.1.41, for Win32 (ia32)
--
-- Host: localhost    Database: simplecrud_zf
-- ------------------------------------------------------
-- Server version	5.1.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `simplecrud_zf`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `simplecrud_zf` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `simplecrud_zf`;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `age` int(3) NOT NULL,
  `email` varchar(100) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Barry','Hale',18,'maxel2011@skanska.org',1),(2,'Lani','Rosario',27,'imogenemcdaniel2011@alcoa.org',1),(3,'Darrel','Pena',37,'2011shalla@kyocera.com',1),(4,'Patrick','Barnett',27,'2011mccormicke@bt.net',1),(5,'Craig','Alexander',37,'1987fullerh@mars.org',1),(6,'Gil','James',39,'maisie2011@weta-digital.biz',0),(7,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(8,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(9,'Audrey','Weber',23,'chardeh@altavista.info',0),(10,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(11,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(12,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(13,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(14,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(15,'September','Norman',19,'fmiriam@five-guys.info',1),(16,'Keane','Fisher',40,'2011hlucius@sega.com',1),(17,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(18,'Gay','Haley',26,'1988acton@pepsi.biz',0),(19,'Megan','James',39,'maisie2011@weta-digital.biz',0),(20,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(21,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(22,'Audrey','Weber',23,'chardeh@altavista.info',0),(23,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(24,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(25,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(26,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(27,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(28,'September','Norman',19,'fmiriam@five-guys.info',1),(29,'Keane','Fisher',40,'2011hlucius@sega.com',1),(30,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(31,'Gay','Haley',26,'1988acton@pepsi.biz',0),(32,'Megan','James',39,'maisie2011@weta-digital.biz',0),(33,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(34,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(35,'Audrey','Weber',23,'chardeh@altavista.info',0),(36,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(37,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(38,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(39,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(40,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(41,'September','Norman',19,'fmiriam@five-guys.info',1),(42,'Keane','Fisher',40,'2011hlucius@sega.com',1),(43,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(44,'Gay','Haley',26,'1988acton@pepsi.biz',0),(45,'Megan','James',39,'maisie2011@weta-digital.biz',0),(46,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(47,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(48,'Audrey','Weber',23,'chardeh@altavista.info',0),(49,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(50,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(51,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(52,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(53,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(54,'September','Norman',19,'fmiriam@five-guys.info',1),(55,'Keane','Fisher',40,'2011hlucius@sega.com',1),(56,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(57,'Gay','Haley',26,'1988acton@pepsi.biz',0),(58,'Megan','James',39,'maisie2011@weta-digital.biz',0),(59,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(60,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(61,'Audrey','Weber',23,'chardeh@altavista.info',0),(62,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(63,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(64,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(65,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(66,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(67,'September','Norman',19,'fmiriam@five-guys.info',1),(68,'Keane','Fisher',40,'2011hlucius@sega.com',1),(69,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(70,'Gay','Haley',26,'1988acton@pepsi.biz',0),(71,'Megan','James',39,'maisie2011@weta-digital.biz',0),(72,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(73,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(74,'Audrey','Weber',23,'chardeh@altavista.info',0),(75,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(76,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(77,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(78,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(79,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(80,'September','Norman',19,'fmiriam@five-guys.info',1),(81,'Keane','Fisher',40,'2011hlucius@sega.com',1),(82,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(83,'Gay','Haley',26,'1988acton@pepsi.biz',0),(84,'Megan','James',39,'maisie2011@weta-digital.biz',0),(85,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(86,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(87,'Audrey','Weber',23,'chardeh@altavista.info',0),(88,'Jena','Williams',28,'1981kirstenk@worlds-of-wonder.biz',1),(89,'Dorothy','Berger',39,'hstephenson2011@tnt-n-v.org',0),(90,'Mia','Lowery',33,'1984graveszane@bcc-research.biz',0),(91,'Camden','Frost',24,'1991daviswinters@level-3-communications.com',0),(92,'Ursula','Wooten',37,'1995halephoebe@bsa.info',1),(93,'September','Norman',19,'fmiriam@five-guys.info',1),(94,'Keane','Fisher',40,'2011hlucius@sega.com',1),(95,'Hamilton','Sharp',38,'2011fgoodwin@embratel.com',1),(96,'Gay','Haley',26,'1988acton@pepsi.biz',0),(97,'Megan','James',39,'maisie2011@weta-digital.biz',0),(98,'Venus','Goodman',27,'clairelivingston1986@psion.biz',1),(99,'Acton','Waller',38,'1986mdelilah@manhattan-associates.org',0),(100,'Audrey','Weber',23,'chardeh@altavista.info',0);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-27 15:23:31
