function log(text) {
    document.body.appendChild(document.createTextNode(text));
}
